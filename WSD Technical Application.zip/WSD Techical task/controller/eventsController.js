const apiClient = require("../middleware/apiClient.js");

const API_ENDPOINT = "https://api.betfair.com/exchange/betting/rest/v1.0/";
const API_EVENTS_URL = API_ENDPOINT + "listEvents/";

exports.get_events_by_id = async (req, res) => {
  const eventTypeID = req.params.id; //This paramter can be changed depending on the event you would like to scrape. (For exsample id 7 is for horse racing). If you want to know the id for different sports, use the events route which pulls all the relevent data^^.

  //These two dates are used to pull all revelant data between the set valuses. These can be alerted to the user presferance.
  const StartDate = "2023-01-01"; //Date A
  const EndDate = "2026-12-31"; //Date B

  const eventFilter = JSON.stringify({
    filter: {
      eventTypeIds: [eventTypeID],
      marketStartTime: {
        from: StartDate + "T00:00:00Z",
        to: EndDate + "T23:59:00Z",
      },
    },
  });

  try {
    const response = await apiClient.post(API_EVENTS_URL, eventFilter);

    res.status(200).json({ status: "success", data: response.data });
  } catch (error) {
    console.error(error);
    res.status(500).json({ status: "error", message: error.message });
  }
};
