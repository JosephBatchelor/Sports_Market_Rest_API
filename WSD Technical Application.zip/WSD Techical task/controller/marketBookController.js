const apiClient = require("../middleware/apiClient.js");
const Sequelize = require("sequelize");
const HorseDetailsModel = (require = require("../model/HorseDetails.js"));

const API_ENDPOINT = "https://api.betfair.com/exchange/betting/rest/v1.0/";
const API_MARKET_CATALOGUE_URL = API_ENDPOINT + "listMarketCatalogue/";
const API_MARKET_BOOK_URL = API_ENDPOINT + "listMarketBook/";

exports.get_market_book_data_all = async (req, res) => {
  const MarketCatalogueurlFilter = JSON.stringify({
    filter: {
      marketStartTime: {
        from: new Date().toISOString(),
      },
    },
    sort: "FIRST_TO_START",
    maxResults: "40", //There is a limit to collection when using market book so i can only collect 40 results a time.
    marketProjection: ["RUNNER_DESCRIPTION"],
  });

  const priceProjection = {
    priceData: ["EX_BEST_OFFERS"],
    exBestOfferOverRides: {
      bestPrice: true,
      bestPricesDepth: 3,
      rollupModel: "STAKE",
      rollupLimit: 20,
    },
    virtualise: false,
    rolloverStakes: false,
  };

  try {
    //This should provide the hourse id, horse name and market id.
    const response1 = await apiClient.post(
      API_MARKET_CATALOGUE_URL,
      MarketCatalogueurlFilter
    );
    const marketIds = response1.data.map((market) => market.marketId);

    //This should get me the horse odds, which is the availableToBack and availableToLay values.
    const response = await apiClient.post(API_MARKET_BOOK_URL, {
      marketIds,
      priceProjection,
    });

    res.status(200).json({ status: "success", data: response.data });
  } catch (error) {
    console.error(error);
    res.status(500).json({ status: "error", message: error.message });
  }
};

exports.get_market_book_data_by_event_id = async (req, res) => {
  const EventId = req.params.eventid;

  const MarketCatalogueurlFilter = JSON.stringify({
    filter: {
      eventIds: [EventId],
      marketStartTime: {
        from: new Date().toISOString(),
      },
    },
    sort: "FIRST_TO_START",
    maxResults: "100",
    marketProjection: ["RUNNER_DESCRIPTION"],
  });

  const priceProjection = {
    priceData: ["EX_BEST_OFFERS"],
    exBestOfferOverRides: {
      bestPrice: true,
      bestPricesDepth: 3,
      rollupModel: "STAKE",
      rollupLimit: 20,
    },
    virtualise: false,
    rolloverStakes: false,
  };

  try {
    const MarketCatalogueResponse = await apiClient.post(
      API_MARKET_CATALOGUE_URL,
      MarketCatalogueurlFilter
    );

    const marketIds = MarketCatalogueResponse.data.map(
      (market) => market.marketId
    );

    const MarketBookresponse = await apiClient.post(API_MARKET_BOOK_URL, {
      marketIds,
      priceProjection,
    });

    const MarketBookFilteredData = MarketBookresponse.data.filter((market) =>
      market.runners.some((runner) => runner.selectionId)
    );

    let Horse_Data = [];

    const HorseDetails = [
      ...new Set(
        MarketCatalogueResponse.data.map((marketData) => {
          return marketData.runners.map((runner) => {
            return {
              selectionId: runner.selectionId,
              runnerName: runner.runnerName,
              odds: {
                availableToBack: MarketBookFilteredData.find((marketData) =>
                  marketData.runners.some(
                    (r) => r.selectionId === runner.selectionId
                  )
                ).runners.find((r) => r.selectionId === runner.selectionId).ex
                  .availableToBack,
                availableToLay: MarketBookFilteredData.find((marketData) =>
                  marketData.runners.some(
                    (r) => r.selectionId === runner.selectionId
                  )
                ).runners.find((r) => r.selectionId === runner.selectionId).ex
                  .availableToLay,
              },
            };
          });
        })
      ),
    ];

    Horse_Data.push({
      HorseDetails: HorseDetails.flat(),
    });

    res.status(200).json({ status: "success", data: Horse_Data });
  } catch (error) {
    console.error(error);
    res.status(500).json({ status: "error", message: error.message });
  }
};

// Exporting the function that retrieves market book data by selection ID
exports.get_market_book_data_by_selection_id = async (req, res) => {
  // Extract the event ID and selection ID from the request parameters
  const EventId = req.params.eventid;
  const SelectionId = req.params.selectionId;

  // Define the market catalogue URL filter
  const MarketCatalogueurlFilter = JSON.stringify({
    filter: {
      eventIds: [EventId],
      marketStartTime: {
        from: new Date().toISOString(),
      },
    },
    sort: "FIRST_TO_START",
    maxResults: "100",
    marketProjection: ["RUNNER_DESCRIPTION"],
  });

  // Define the price projection
  const priceProjection = {
    priceData: ["EX_BEST_OFFERS"],
    exBestOfferOverRides: {
      bestPrice: true,
      bestPricesDepth: 3,
      rollupModel: "STAKE",
      rollupLimit: 20,
    },
    virtualise: false,
    rolloverStakes: false,
  };

  try {
    // Get the market catalogue data from the API
    const MarketCatalogueResponse = await apiClient.post(
      API_MARKET_CATALOGUE_URL,
      MarketCatalogueurlFilter
    );

    // Extract the market IDs from the market catalogue data
    const marketIds = MarketCatalogueResponse.data.map(
      (market) => market.marketId
    );

    // Get the market book data from the API for the specified market IDs and price projection
    const MarketBookresponse = await apiClient.post(API_MARKET_BOOK_URL, {
      marketIds,
      priceProjection,
    });

    // Filter the market book data to only include the data for the specified selection ID
    const MarketBookFilteredData = MarketBookresponse.data.filter((market) =>
      market.runners.some(
        (runner) => runner.selectionId === parseInt(SelectionId)
      )
    );

    // Filter the market catalogue data to only include the data for the specified selection ID
    const MarketCatalogueFilteredData = MarketCatalogueResponse.data.filter(
      (market) =>
        market.runners.some(
          (runner) => runner.selectionId === parseInt(SelectionId)
        )
    );

    let Horse_Data = [];

    const HorseDetails = [
      ...new Set(
        MarketCatalogueFilteredData.map((marketData) => {
          return {
            selectionId: parseInt(SelectionId),
            runnerName: marketData.runners.find(
              (runner) => runner.selectionId === parseInt(SelectionId)
            ).runnerName,
            odds: {
              availableToBack: MarketBookFilteredData.find((marketData) =>
                marketData.runners.some(
                  (runner) => runner.selectionId === parseInt(SelectionId)
                )
              ).runners.find(
                (runner) => runner.selectionId === parseInt(SelectionId)
              ).ex.availableToBack,
              availableToLay: MarketBookFilteredData.find((marketData) =>
                marketData.runners.some(
                  (runner) => runner.selectionId === parseInt(SelectionId)
                )
              ).runners.find(
                (runner) => runner.selectionId === parseInt(SelectionId)
              ).ex.availableToLay,
            },
          };
        })
      ),
    ];

    Horse_Data.push({
      HorseDetails: [HorseDetails[0]], //Returns one entry and no duplicates.
    });

    let selectionId = Horse_Data[0].HorseDetails[0].selectionId;
    let selectionIdAsString = selectionId.toString();

    let runnerName = Horse_Data[0].HorseDetails[0].runnerName;
    let runnerNameString = runnerName.toString();

    let availableToBackPrice =
      Horse_Data[0].HorseDetails[0].odds.availableToBack[0].price;
    let availableToBackPriceString = availableToBackPrice.toString();

    let availableToBackSize =
      Horse_Data[0].HorseDetails[0].odds.availableToBack[0].size;
    let availableToBackSizeString = availableToBackSize.toString();

    let availableToLayPrice =
      Horse_Data[0].HorseDetails[0].odds.availableToLay[0].price;
    let availableToLayPriceString = availableToLayPrice.toString();

    let availableToLaySize =
      Horse_Data[0].HorseDetails[0].odds.availableToLay[0].size;
    let availableToLaySizeString = availableToLaySize.toString();

    HorseDetailsModel.create({
      selectionId: selectionIdAsString,
      runnerName: runnerNameString,
      availableToBackPrice: availableToBackPriceString,
      availableToBackSize: availableToBackSizeString,
      availableToLayPrice: availableToLayPriceString,
      availableToLaySize: availableToLaySizeString,
    })
      .then(() => {
        // Data stored successfully
      })
      .catch((error) => {
        console.error(error);
      });

    res.status(200).json({ status: "success", data: Horse_Data });
  } catch (error) {
    console.error(error);
    res.status(500).json({ status: "error", message: error.message });
  }
};
