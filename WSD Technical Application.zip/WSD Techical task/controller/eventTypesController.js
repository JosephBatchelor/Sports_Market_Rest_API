const apiClient = require("../middleware/apiClient.js");

const API_ENDPOINT = "https://api.betfair.com/exchange/betting/rest/v1.0/";
const API_EVENT_TYPES_URL = API_ENDPOINT + "listEventTypes/";

exports.get_event_types_all = async (req, res) => {
  const eventTypesFilter = JSON.stringify({ filter: {} }); //A blank filter return all event data.
  try {
    const response = await apiClient.post(
      API_EVENT_TYPES_URL,
      eventTypesFilter
    );
    res.status(200).json({ status: "success", data: response.data });
  } catch (error) {
    console.error(error);
    res.status(500).json({ status: "error", message: error.message });
  }
};
