const axios = require("axios");

// Define the headers to be sent with each API request
const API_HEADERS = {
  "X-Application": "*App key*",
  "X-Authentication": "*Session token*",
  "content-type": "application/json",
};

// Define the rate limit for API requests.
// The API documentation does not state the rate limit for data calls,
// but there is a point system that determines the amount of data pulled per request.
const RATE_LIMIT = 60;

// Keep track of the number of API requests
let requestCount = 0;

// Create an instance of axios with the API headers
const apiClient = axios.create({
  headers: API_HEADERS,
});

// Add an interceptor to handle API rate limiting
apiClient.interceptors.request.use((config) => {
  // If the number of API requests has reached the rate limit
  if (requestCount >= RATE_LIMIT) {
    // Return a new promise that will resolve once the rate limit has been reached
    return new Promise((resolve, reject) => {
      // Wait for 60 seconds before resolving the promise
      setTimeout(() => {
        // Reset the request count
        requestCount = 0;
        // Resolve the promise with the API request config
        resolve(config);
      }, 60000);
    });
  } else {
    // Increment the request count
    requestCount++;
    // Return the API request config
    return config;
  }
});

// Export the apiClient as a module
module.exports = apiClient;
