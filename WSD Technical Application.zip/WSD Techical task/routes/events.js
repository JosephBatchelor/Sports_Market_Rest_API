const eventsController = require("../controller/eventsController.js");
const express = require("express");
const router = express.Router();

router.get("/events/:id", eventsController.get_events_by_id);

module.exports = router;
