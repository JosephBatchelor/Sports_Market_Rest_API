const eventTypesController = require("../controller/eventTypesController.js");
const express = require("express");
const router = express.Router();

router.get("/event-types", eventTypesController.get_event_types_all);

module.exports = router;
