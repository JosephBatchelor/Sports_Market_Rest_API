const marketBookController = require("../controller/marketBookController.js");
const express = require("express");
const router = express.Router();

router.get("/market-book", marketBookController.get_market_book_data_all);

router.get(
  "/market-book/:eventid",
  marketBookController.get_market_book_data_by_event_id
);

router.get(
  "/market-book/:eventid/:selectionId",
  marketBookController.get_market_book_data_by_selection_id
);

module.exports = router;
