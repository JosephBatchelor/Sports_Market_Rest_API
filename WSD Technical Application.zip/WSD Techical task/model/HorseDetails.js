const { Sequelize, DataTypes } = require("sequelize");

const sequelize = new Sequelize("*database*", "*username*", "*password*", {
  host: "localhost",
  dialect: "postgres",
});

sequelize
  .authenticate()
  .then(() => {
    console.log("Connection has been established successfully.");
  })
  .catch((err) => {
    console.error("Unable to connect to the database:", err);
  });

const HorseDetails = sequelize.define("HorseDetails", {
  selectionId: {
    type: Sequelize.INTEGER,
    primaryKey: true,
  },
  runnerName: {
    type: Sequelize.STRING,
  },
  availableToBackPrice: {
    type: Sequelize.STRING,
    allowNull: true,
  },
  availableToBackSize: {
    type: Sequelize.STRING,
    allowNull: true,
  },
  availableToLayPrice: {
    type: Sequelize.STRING,
    allowNull: true,
  },
  availableToLaySize: {
    type: Sequelize.STRING,
    allowNull: true,
  },
});

HorseDetails.sync({ force: true }).then(() => {
  console.log("Table created successfully");
});

module.exports = HorseDetails;
