const express = require("express");
const Sequelize = require("sequelize");
const app = express();

const eventTypesRouter = require("./routes/eventTypes.js");

const eventsRouter = require("./routes/events.js");

const MarketBookRouter = require("./routes/marketBook.js");

app.use("/", eventTypesRouter);

app.use("/", eventsRouter);

app.use("/", MarketBookRouter);

app.listen(5000, () => {
  console.log("Running...");
});
