const express = require("express");

// Create an express application instance
const app = express();

// Import the supertest library to make HTTP requests
const request = require('supertest');

// Test the "/event-types" endpoint
describe("/event-types", () => {
    // Test to ensure that the endpoint returns all data for all events
    it('Should return all data for all events', async () => {
        // Send a GET request to the "/event-types" endpoint
        const response = await request(app)
        .get("/event-types")

        // Check that the status code is 200 (success)
        expect(response.statusCode).toBe(200)

        // Check that the "horsedetails" property exists and is not null
        expect(response.body.horsedetails).toBeTruthy();
    });
});

// Test the "/events" endpoint
describe("/events", () => {
    // Test to ensure that the endpoint returns all data for a specific event id
    it('Should return all data for a specific event id', async () => {
        // Define the id of the event to retrieve
        const id = 7;

        // Send a GET request to the "/events/{id}" endpoint
        const response = await request(app)
        .get(`/events/${id}`)

        // Check that the status code is 200 (success)
        expect(response.statusCode).toBe(200)

        // Check that the "horsedetails" property exists and is not null
        expect(response.body.horsedetails).toBeTruthy();
    });
});

// Test the "/market-book" endpoint
describe("/market-book", () => {
    // Test to ensure that the endpoint returns all market data for a specific event id
    it('Should return all market data for a specific event id', async () => {
        // Send a GET request to the "/market-book" endpoint
        const response = await request(app)
        .get("/market-book")

        // Check that the status code is 200 (success)
        expect(response.statusCode).toBe(200)

        // Check that the "horsedetails" property exists and is not null
        expect(response.body.horsedetails).toBeTruthy();
    });
});

// Test the "/market-book/{eventid}" endpoint
describe('Market-Book specific event retrieval', () => {
    // Test to ensure that the endpoint returns market data for a specific event id
    it('Should return market data for a specific event id', async () => {
        // Define the id of the event to retrieve
        const eventid = 32087017;

        // Send a GET request to the "/market-book/{eventid}" endpoint
        const response = await request(app)
        .get(`/market-book/${eventid}`)

        // Check that the status code is 200 (success)
        expect(response.statusCode).toBe(200)

        // Check that the "horsedetails" property exists and is not null
        expect(response.body.horsedetails).toBeTruthy()
    });
  });

// Test the "/market-book/{eventid}/${selectionid}" endpoint
  describe('Market-Book spesific runner retriveal', () => {
    it('Should return data for a specific event id', async () => {
      const eventid = 32087017;
      const  selectionid = 10091032;

      // Send a GET request to the "/market-book/{eventid}/${selectionid}" endpoint
      const response = await request(app) 
        .get(`/market-book/${eventid}/${selectionid}`)
        
        // Check that the status code is 200 (success)
        expect(response.statusCode).toBe(200)

        // Check that the "horsedetails" property exists and is not null
        expect(response.body.horsedetails).toBeTruthy();
    });
  });